package com.example.modernfurniture;

public class Common {

    public static String model = "model.sfb";
}
